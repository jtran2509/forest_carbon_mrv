import os
import sys
import glob
import argparse
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from monai.losses import DiceCELoss
import subprocess

# ===== DIAGNOSTIC - CHẠY TRONG SAGEMAKER CONTAINER =====
print("=" * 50)
print("DIAGNOSTIC INSIDE SAGEMAKER CONTAINER:")
print(f"PyTorch version: {torch.__version__}")
print(f"CUDA available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"CUDA version: {torch.version.cuda}")
    print(f"GPU count: {torch.cuda.device_count()}")
    print(f"GPU name: {torch.cuda.get_device_name(0)}")
else:
    print("WARNING: CUDA is NOT available in this container")

# Thử chạy nvidia-smi
try:
    result = subprocess.run(['nvidia-smi'], capture_output=True, text=True)
    print(f"nvidia-smi exit code: {result.returncode}")
    if result.returncode == 0:
        print("nvidia-smi output (first 500 chars):")
        print(result.stdout[:500])
    else:
        print(f"nvidia-smi error: {result.stderr}")
except Exception as e:
    print(f"Could not run nvidia-smi: {e}")
print("=" * 50)
# ===== END DIAGNOSTIC =====

current_dir = os.path.dirname(os.path.abspath(__file__))
src_path = os.path.join(current_dir, 'src')
if src_path not in sys.path:
    sys.path.insert(0, src_path)

from model import AttentionUNet
from dataset import ForestCarbonDataset, get_train_transform
from utils import prepare_data_loader, evaluate_model

def train():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=30)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--learning-rate', type=float, default=1e-4)
    parser.add_argument('--model-dir', type=str, default=os.environ.get('SM_MODEL_DIR', '/opt/ml/model'))
    parser.add_argument('--checkpoint-dir', type=str, default=os.environ.get('SM_CHECKPOINT_DIR', '/opt/ml/checkpoints'))
    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"GPU count: {torch.cuda.device_count()}")
        print(f"GPU name: {torch.cuda.get_device_name(0)}")

    data_dir = '/opt/ml/input/data/training'

    all_images = glob.glob(os.path.join(data_dir, '**/images/chip_*.npy'), recursive=True)
    all_masks = glob.glob(os.path.join(data_dir, '**/masks/mask_*.npy'), recursive=True)
    all_images.sort()
    all_masks.sort()

    print(f"Found {len(all_images)} images, {len(all_masks)} masks")
    if len(all_images) > 0:
        print(f"Sample image path: {all_images[0]}")
        print(f"Sample mask path: {all_masks[0]}")

    assert len(all_images) == len(all_masks)

    train_loader, val_loader, test_loader = prepare_data_loader(
        all_images, all_masks,
        batch_size=args.batch_size,
        train_split=0.7, val_split=0.15, test_split=0.15
    )

    model = AttentionUNet(img_ch=4, output_ch=1).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
    loss_fn = DiceCELoss(sigmoid=True)

    # ========== ADD SCHEDULER FOR LEARNING RATE =============
    # Reduce learning rate when validation loss plateau
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="min",        
        factor=0.5,        # Reduce learning rate by half
        patience=3,        # Wait 3 epochs without improvement
        cooldown=1       # Wait 1 epoch after reducing    
    )
    # ========================================================

    start_epoch = 0
    best_val_loss = float('inf')

    if os.path.exists(args.checkpoint_dir):
        checkpoint_files = glob.glob(os.path.join(args.checkpoint_dir, '*.pth'))
        if checkpoint_files:
            latest = max(checkpoint_files, key=os.path.getctime)
            checkpoint = torch.load(latest, map_location=device)
            model.load_state_dict(checkpoint['model_state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            start_epoch = checkpoint['epoch'] + 1
            best_val_loss = checkpoint.get('best_val_loss', float('inf'))
            print(f"Resumed from checkpoint at epoch {start_epoch}")

    print(f"Starting training for {args.epochs} epochs...")

    for epoch in range(start_epoch, args.epochs):
        model.train()
        train_loss = 0
        for batch in train_loader:
            inputs = batch['image'].to(device)
            labels = batch['label'].to(device)

            optimizer.zero_grad()
            outputs = model(inputs)
            loss = loss_fn(outputs, labels)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        avg_train_loss = train_loss / len(train_loader)

        model.eval()
        val_loss = 0
        with torch.no_grad():
            for batch in val_loader:
                inputs = batch['image'].to(device)
                labels = batch['label'].to(device)
                outputs = model(inputs)
                loss = loss_fn(outputs, labels)
                val_loss += loss.item()

        avg_val_loss = val_loss / len(val_loader)
        current_lr = optimizer.param_groups[0]['lr']
        print(f"Epoch {epoch} | Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f} | LR: {current_lr:.6f}")

        # Save checkpoint if validation loss improves
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            checkpoint_path = os.path.join(args.checkpoint_dir, f'checkpoint_epoch_{epoch}.pth')
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'best_val_loss': best_val_loss
            }, checkpoint_path)
            print(f"✅ Saved checkpoint to {checkpoint_path}")

        # 👈 QUAN TRỌNG: Gọi scheduler MỖI EPOCH (đặt sau if)
        scheduler.step(avg_val_loss)

    final_iou, final_dice = evaluate_model(model, test_loader, device)
    print(f"Final IoU: {final_iou:.4f}, Final Dice: {final_dice:.4f}")
    torch.save(model.state_dict(), os.path.join(args.model_dir, 'model.pth'))

if __name__ == '__main__':
    train()
