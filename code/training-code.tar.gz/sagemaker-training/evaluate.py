import os
import glob
import torch
import numpy as np
import boto3
from torch.utils.data import DataLoader
from monai.metrics import compute_iou
import sys

# Thêm thư mục src vào path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from model import AttentionUNet
from dataset import ForestCarbonDataset

def compute_dice(pred, target, smooth=1e-6):
    pred = pred.view(-1)
    target = target.view(-1)
    intersection = (pred * target).sum()
    return (2. * intersection + smooth) / (pred.sum() + target.sum() + smooth)

def evaluate():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    # Đường dẫn dữ liệu
    data_dir = '/opt/ml/input/data/training'

    # Tìm tất cả image và mask
    all_images = glob.glob(os.path.join(data_dir, '**/images/chip_*.npy'), recursive=True)
    all_masks = glob.glob(os.path.join(data_dir, '**/masks/mask_*.npy'), recursive=True)
    all_images.sort()
    all_masks.sort()

    print(f"Found {len(all_images)} images, {len(all_masks)} masks")

    # Lấy test set (15% cuối)
    dataset_size = len(all_images)
    test_start = int(dataset_size * 0.85)
    test_images = all_images[test_start:]
    test_masks = all_masks[test_start:]

    print(f"Test set size: {len(test_images)} images")

    # Tạo test loader
    test_ds = ForestCarbonDataset(test_images, test_masks, transform=None)
    test_loader = DataLoader(test_ds, batch_size=32, shuffle=False, num_workers=0, pin_memory=False)

    model = AttentionUNet(img_ch=4, output_ch=1).to(device)

    
    checkpoint_bucket = "forest-carbon-dung-results"
    checkpoint_prefix = "checkpoints-4bands/"

    s3 = boto3.client('s3')
    response = s3.list_objects_v2(Bucket=checkpoint_bucket, Prefix=checkpoint_prefix)

    checkpoint_files = []
    if 'Contents' in response:
        for obj in response['Contents']:
            if 'checkpoint_epoch_' in obj['Key'] and obj['Key'].endswith('.pth'):
                checkpoint_files.append(obj['Key'])

    if checkpoint_files:
        checkpoint_files.sort()
        latest_checkpoint = checkpoint_files[-1]

        local_checkpoint = '/tmp/checkpoint.pth'
        s3.download_file(checkpoint_bucket, latest_checkpoint, local_checkpoint)
        print(f"Loaded checkpoint: {latest_checkpoint}")

        checkpoint = torch.load(local_checkpoint, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])
        epoch = checkpoint.get('epoch', 'unknown')
        best_val_loss = checkpoint.get('best_val_loss', 'N/A')
        print(f"Resumed from epoch {epoch}, best_val_loss={best_val_loss}")
    else:
        print("No checkpoint found!")
        return

    # Đánh giá
    model.eval()
    all_iou = []
    all_dice = []

    with torch.no_grad():
        for batch_idx, batch in enumerate(test_loader):
            inputs = batch['image'].to(device)
            labels = batch['label'].to(device)
            outputs = model(inputs)
            preds = (torch.sigmoid(outputs) > 0.5).float()

            iou = compute_iou(y_pred=preds.cpu(), y=labels.cpu(), ignore_empty=False)
            all_iou.append(torch.mean(iou).item())

            for i in range(preds.shape[0]):
                dice = compute_dice(preds[i].cpu(), labels[i].cpu())
                all_dice.append(dice)

            if (batch_idx + 1) % 50 == 0:
                print(f"Processed {batch_idx + 1}/{len(test_loader)} batches")

    print(f"\n{'='*50}")
    print(f"FINAL EVALUATION RESULTS:")
    print(f"Test samples: {len(all_dice)}")
    print(f"Test IoU: {np.mean(all_iou):.4f}")
    print(f"Test Dice: {np.mean(all_dice):.4f}")
    print(f"{'='*50}")

if __name__ == '__main__':
    evaluate()
