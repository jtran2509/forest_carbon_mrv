import numpy as np
import torch
from torch.utils.data import Dataset
from monai.transforms import Compose, RandFlipd, RandRotate90d, RandGaussianNoised, ToTensord, RandAdjustContrastd

class ForestCarbonDataset(Dataset):
    def __init__(self, image_files, mask_files, transform=None):
        self.image_files = image_files
        self.mask_files = mask_files
        self.transform = transform

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        image = np.load(self.image_files[idx])
        mask = np.load(self.mask_files[idx])
        mask = np.expand_dims(mask, axis=0)

        data_dict = {"image": image, "label": mask}
        if self.transform:
            data_dict = self.transform(data_dict)
        return data_dict

def get_train_transform():
    return Compose([
        RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=0),
        RandFlipd(keys=['image', 'label'], prob=0.5, spatial_axis=1),
        RandRotate90d(keys=['image', 'label'], prob=0.75, max_k=3),
        RandGaussianNoised(keys=['image'], prob=0.2, mean=0.0, std=0.01),
        RandAdjustContrastd(keys=['image'], prob=0.2, gamma=(0.7, 1.3)),
        ToTensord(keys=['image', 'label'])
    ])
